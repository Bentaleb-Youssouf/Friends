package ti.dam.bentaleb.benali.friends;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    private static final String USERNAME = "dam";
    private static final String PASSWORD = "123";

    private EditText userEd, passEd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        userEd = (EditText) findViewById(R.id.usernameET);
        passEd = (EditText) findViewById(R.id.passwordET);
    }

    public void loginCheck(View view){
        String userText = userEd.getText().toString(),
               passText = passEd.getText().toString();

        if(userText.equals("") || passText.equals("")){
            Toast.makeText(this,"Insérer des valeurs S.V.P !" , Toast.LENGTH_SHORT).show();
            Log.e("LoginActivity","Les champs vide !");
        }else{
            if(userText.equals(USERNAME) && passText.equals(PASSWORD)){
                Intent intent = new Intent(this, FriendActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("USERNAME",USERNAME);
                bundle.putString("PASSWORD",PASSWORD);
                intent.putExtras(bundle);
                startActivity(intent);
            }else{
                Toast.makeText(this,"Les informations sont incorrect !" , Toast.LENGTH_SHORT).show();
                Log.e("LoginActivity","Les informations sont incorrect !");
            }

        }

    }
}
