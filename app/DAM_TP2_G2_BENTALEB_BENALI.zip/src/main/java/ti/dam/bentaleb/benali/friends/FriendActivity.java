package ti.dam.bentaleb.benali.friends;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class FriendActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friend);

        Bundle bundle = getIntent().getExtras();
        TextView mainTV = (TextView) findViewById(R.id.mainUser);
        mainTV.setText("Bienvenue, " + bundle.getString("USERNAME") + " votre mot de passe est : " + bundle.get("PASSWORD"));

    }
}
